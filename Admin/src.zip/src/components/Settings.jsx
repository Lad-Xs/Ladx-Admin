import React from "react";

const Settings = () => {
  return <div>hi</div>;
};

export default Settings;
